package com.example.utspraktik_if6_10119075_aditiyamusthafakamil

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainActivity : AppCompatActivity(
) //25.05.2023,10119075,AditiyaMusthafaKamil,IF6
{
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        <!-- .Konten/Beranda -->

        <Relative Layout
        xmlns android = "http://schemas.android.com/apk/res/android"
        android:id="@+id/konten_break"
        android:layout_width="fill_parent"
        android:layout_height="fill_parent"
        android:background=;@drawable/konten_;
        />

        <!-- drawable/.xml -->
        <vector
        xmlns:android="http://schemas.android.com/apk/res/android"
        xmlns:aapt="http://schemas.android.com/aapt"
        android:width="360dp"
        android:height="1841dp"
        android:viewportWidth="360"
        android:viewportHeight="1841"
        >

         <group>
          <clip-path
            android:pathData="M0 0H360V1841H0V0Z"
        />
         <path
           android:pathData="M0 0V1841H360V0"
           android:fillColor="#EFF2F3"
        />
         </group>
        <
        <android.view.View
        android:id="@+id/canvas"
        android:background="#F5F5F5" />
        </vector>
    }
}

annotation class drawable
